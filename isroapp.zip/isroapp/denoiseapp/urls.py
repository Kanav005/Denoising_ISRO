from django.urls import path,include
from .views import denoise

urlpatterns = [
    path('',denoise)
]
