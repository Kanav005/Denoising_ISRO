from django.shortcuts import render
from django.http import HttpResponse
import numpy as np
import rasterio
from skimage.restoration import denoise_tv_chambolle
import os

# Create your views here.


def denoise(request):
    if request.method=="GET":
        return render(request,"formpage.html")

    elif request.method=="POST":
        uploaded_filedata= request.FILES['qub'].read()
        hdr_file=request.FILES['hdr'].read()
        w=float(request.POST["weight"])
        iter=int(request.POST["iterations"])

        with open('data.qub','wb') as file:
            file.write(uploaded_filedata)
        with open('data.hdr','wb') as file:
            file.write(hdr_file)

        r=rasterio.open('data.qub')
        img=r.read()
        denoised_img = denoise_tv_chambolle(img, weight=w, max_num_iter=iter)

        with rasterio.open(
                'Denoised_image.qub',
                'w',
                driver='ENVI',
                height=img.shape[1],
                width=img.shape[2],
                count=img.shape[0],
                dtype=np.float32,
                crs=r.profile['crs'],
                transform=r.profile['transform'],
        ) as dest_file:
            dest_file.write(denoised_img)

        with open('Denoised_image.qub', 'rb') as f:
            data= f.read()
            content_type = 'image/qub'
            response = HttpResponse(data, content_type=content_type)
            response['Content-Disposition'] = 'attachment; filename="Denoised_image.qub"'
        r.close()
        os.remove('data.qub')
        os.remove('data.hdr')
        os.remove('Denoised_image.hdr')
        os.remove('Denoised_image.qub')
        return response



